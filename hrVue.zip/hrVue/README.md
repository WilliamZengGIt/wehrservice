# wehr

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

菜单项数据加载成功之后，在前端有几个可以存放的地方:
1.sessionStorage(不安全)
2.localStorage（不安全）
3.vuex（状态管理工具）本项目用vuex 前端数据存在vuex里面
