import Vue from 'vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue';


import {postKeyValueRequest} from "./utils/api";
import{postRequest} from "./utils/api";
import{putRequest} from "./utils/api";
import {deleteRequest} from "./utils/api";
import {getRequest} from "./utils/api";
import {initMenu} from "./utils/menus";
import 'font-awesome/css/font-awesome.min.css'

//请求方法的封装。使用方法：this.postReuqest。相当于全局注册；制作vue插件 方便引用
Vue.prototype.postRequest=postRequest;
Vue.prototype.postKeyValueRequest=postKeyValueRequest;
Vue.prototype.putRequest=putRequest;
Vue.prototype.deleteRequest=deleteRequest;
Vue.prototype.getRequest=getRequest;


Vue.use(ElementUI,{size:'small'});
Vue.config.productionTip = false

//全局导航守卫 类似于后端过滤器  详细方法看文档
//配置除了登录不需要初始化菜单Menu 其它方法都需要
router.beforeEach((to,from,next)=>{
  if (to.path=='/'){
    next();
  }else {
    //如果登录就进入
    if(window.sessionStorage.getItem("user")){
      initMenu(router,store);
      next();
    }else {

      next('/?redirect='+to.path);
    }

  }


})


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
